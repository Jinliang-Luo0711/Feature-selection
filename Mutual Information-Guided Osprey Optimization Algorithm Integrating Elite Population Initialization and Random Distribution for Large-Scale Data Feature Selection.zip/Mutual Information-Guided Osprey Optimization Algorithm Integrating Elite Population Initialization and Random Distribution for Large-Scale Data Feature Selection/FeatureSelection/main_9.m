function results = main_9(settings)
%MAIN_9 Run the feature-selection experiments from the supplied DATA files.
%   results = main_9 runs all 18 datasets and 10 algorithms, with 20
%   independent searches per algorithm. New results are saved in outputs.
%
%   For a short first run using L1 and the two proposed algorithms:
%   results = main_9(struct('datasetIndices',1,'algorithmIndices',1:2, ...
%       'numRuns',1,'maxIterations',10));
%
%   Edit the defaults below or pass a settings structure to select datasets,
%   algorithms, repetition count, population size and iteration count.
%   Requires Statistics and Machine Learning Toolbox.

if nargin < 1
    settings = struct;
end
% Experiment settings. Dataset indices follow the L1-L18 order below.
defaults = struct('numRuns',30,'populationSize',10,'maxIterations',100, ...
    'holdoutFraction',0.2,'datasetIndices',1:18,'algorithmIndices',1:10, ...
    'makePlots',true,'saveResults',true,'outputDirectory','');
% defaults = struct('numRuns',2,'populationSize',4,'maxIterations',100, ...
%     'holdoutFraction',0.2,'datasetIndices',1,'algorithmIndices',1:10, ...
%     'makePlots',true,'saveResults',true,'outputDirectory','');
validateattributes(settings,{'struct'},{'scalar'});
settingNames = fieldnames(settings);
assert(all(ismember(settingNames,fieldnames(defaults))), ...
    'publicfs:Settings','Unknown experiment setting.');
for index = 1:numel(settingNames)
    defaults.(settingNames{index}) = settings.(settingNames{index});
end
settings = defaults;
validateattributes(settings.numRuns,{'numeric'},{'scalar','integer','positive'});
validateattributes(settings.populationSize,{'numeric'},{'scalar','integer','>=',4});
validateattributes(settings.maxIterations,{'numeric'},{'scalar','integer','positive'});
assert(mod(settings.populationSize,2)==0, ...
    'publicfs:Population','The original COA implementation uses an even population.');
assert(settings.holdoutFraction>0 && settings.holdoutFraction<1);
assert(~isempty(settings.datasetIndices) && ...
    all(ismember(settings.datasetIndices,1:18)) && ...
    numel(unique(settings.datasetIndices))==numel(settings.datasetIndices));
assert(~isempty(settings.algorithmIndices) && ...
    all(ismember(settings.algorithmIndices,1:10)) && ...
    numel(unique(settings.algorithmIndices))==numel(settings.algorithmIndices));
settings.datasetIndices = settings.datasetIndices(:)';
settings.algorithmIndices = settings.algorithmIndices(:)';
if ismember(10,settings.algorithmIndices)
    assert(settings.maxIterations>=2, ...
        'publicfs:Iterations','The two-stage ACO-MI schedule requires at least two iterations.');
end

here = fileparts(mfilename('fullpath'));
addpath(here,fullfile(here,'external','ACO_MI'));
assert(~isempty(which('cvpartition')) && ~isempty(which('fitcknn')), ...
    'publicfs:Toolbox','Install Statistics and Machine Learning Toolbox to run main_9.');
datasets = paper_datasets();
algorithmNames = {'DLMt-OOA','MIDLMt-OOA','AOA','BAT','COA', ...
    'CFOA','FLO','PDO','RSA','ACO-MI'};
algorithmFunctions = {@IIOOA_t,@IIOOA_t_MI,@AOA2021,@BAT,@COA, ...
    @CFOA,@FLO,@PDO2022,@RSA,@ACO_MI};
numberOfDatasets = height(datasets);
numberOfAlgorithms = numel(algorithmNames);
numberOfRuns = settings.numRuns;
for datasetIndex = settings.datasetIndices
    dataFile = fullfile(here,'DATA',char(datasets.File(datasetIndex)));
    assert(isfile(dataFile),'publicfs:Dataset','Dataset file is missing: %s',dataFile);
end
if settings.saveResults
    if isempty(settings.outputDirectory)
        settings.outputDirectory = fullfile(here,'outputs', ...
            char(datetime('now','Format','yyyyMMdd_HHmmss_SSS')));
    end
    if ~isfolder(settings.outputDirectory)
        mkdir(settings.outputDirectory);
    end
end
fprintf('Starting %d datasets, %d algorithms, %d runs and %d iterations.\n', ...
    numel(settings.datasetIndices),numel(settings.algorithmIndices), ...
    numberOfRuns,settings.maxIterations);

results = struct;
results.Settings = settings;
results.Datasets = datasets;
results.AlgorithmNames = algorithmNames;
results.Cdata_acc = cell(numberOfDatasets,1);
results.Cdata_Fitnsss = cell(numberOfDatasets,1);
results.Cdata_Nf = cell(numberOfDatasets,1);
results.Cdata_time = cell(numberOfDatasets,1);
results.SelectedFeatures = cell(numberOfDatasets,numberOfRuns,numberOfAlgorithms);
results.Curves = cell(numberOfDatasets,numberOfRuns,numberOfAlgorithms);
results.MeanCurves = cell(numberOfDatasets,numberOfAlgorithms);
results.Partitions = cell(numberOfDatasets,1);
results.RngBeforeSearch = cell(numberOfDatasets,numberOfRuns,numberOfAlgorithms);
results.ACOInfo = cell(numberOfDatasets,numberOfRuns);
results.ACOPreparationSeconds = nan(numberOfDatasets,1);
metricNames = {'Acc','Fitness','Nf','Time'};
for index = 1:numel(metricNames)
    results.(['Mean_' metricNames{index}]) = nan(numberOfDatasets,numberOfAlgorithms);
    results.(['Std_' metricNames{index}]) = nan(numberOfDatasets,numberOfAlgorithms);
end

for datasetIndex = settings.datasetIndices
    entry = datasets(datasetIndex,:);
    fprintf('\nLoading %s %s (%d samples, %d features).\n', ...
        char(entry.PaperID),char(entry.Name),entry.ExpectedInstances,entry.ExpectedFeatures);
    source = load(fullfile(here,'DATA',char(entry.File)));
    variableNames = fieldnames(source);
    assert(isscalar(variableNames), ...
        'publicfs:Dataset','Expected one numeric matrix in %s.',entry.File);
    A = source.(variableNames{1});
    assert(isnumeric(A) && ismatrix(A) && ...
        size(A,1)==entry.ExpectedInstances && ...
        size(A,2)==entry.ExpectedFeatures+1, ...
        'publicfs:Dataset','Dataset dimensions differ from the manuscript manifest.');
    label = A(:,end);
    feat = A(:,1:end-1);

    partitionRng = rng;
    HO = cvpartition(label,'HoldOut',settings.holdoutFraction);
    results.Partitions{datasetIndex} = struct('Training',training(HO), ...
        'Validation',test(HO),'RngBeforePartition',partitionRng);

    acoOptions = struct;
    if ismember(10,settings.algorithmIndices)
        fprintf('Preparing ACO-MI on the training partition.\n');
        acoOptions = aco_mi_options();
        acoOptions.ants = settings.populationSize;
        acoOptions.numIntervals = 10;
        acoOptions.iterations = 20;
        acoOptions.totalIterations = settings.maxIterations;
        acoOptions.fitnessMode = "common_objective";
        acoOptions.maxExactPairs = Inf;
        acoOptions.maxCachedPatterns = Inf;
        acoOptions.pilotFeatureCap = Inf;
        acoOptions.samplerBackend = "matlab";
        acoOptions.verbose = false;
        acoOptions = rmfield(acoOptions,'seed');
        preparationClock = tic;
        model = aco_mi_prepare(feat(training(HO),:),label(training(HO)),acoOptions);
        results.ACOPreparationSeconds(datasetIndex) = toc(preparationClock);
        if isfield(model,'etaMatrix')
            unusedFields = intersect(fieldnames(model), ...
                {'patterns','patternID','multiplicity','pairMatrix','lazyPairCache'});
            model = rmfield(model,unusedFields);
        end
        acoOptions.preparationModel = model;
    end

    accuracy = nan(numberOfRuns,numberOfAlgorithms);
    fitness = nan(numberOfRuns,numberOfAlgorithms);
    selectedCount = nan(numberOfRuns,numberOfAlgorithms);
    elapsed = nan(numberOfRuns,numberOfAlgorithms);
    for runIndex = 1:numberOfRuns
        for algorithmIndex = settings.algorithmIndices
            results.RngBeforeSearch{datasetIndex,runIndex,algorithmIndex} = rng;
            optimizer = algorithmFunctions{algorithmIndex};
            if algorithmIndex == 10
                [score,acc,nf,sf,curve,seconds,info] = optimizer(feat,label, ...
                    settings.populationSize,settings.maxIterations,HO,acoOptions);
                results.ACOInfo{datasetIndex,runIndex} = info;
            else
                [score,acc,nf,sf,curve,seconds] = optimizer(feat,label, ...
                    settings.populationSize,settings.maxIterations,HO);
            end
            fitness(runIndex,algorithmIndex) = score;
            accuracy(runIndex,algorithmIndex) = acc;
            selectedCount(runIndex,algorithmIndex) = nf;
            elapsed(runIndex,algorithmIndex) = seconds;
            results.SelectedFeatures{datasetIndex,runIndex,algorithmIndex} = sf;
            results.Curves{datasetIndex,runIndex,algorithmIndex} = curve(:)';
            fprintf('\n%s %s | run %d/%d | %s | fitness %.8g | accuracy %.6f | features %d\n', ...
                char(entry.PaperID),char(entry.Name),runIndex,numberOfRuns, ...
                algorithmNames{algorithmIndex},score,acc,nf);
        end
    end
    results.Cdata_acc{datasetIndex} = accuracy;
    results.Cdata_Fitnsss{datasetIndex} = fitness;
    results.Cdata_Nf{datasetIndex} = selectedCount;
    results.Cdata_time{datasetIndex} = elapsed;
    measurements = {accuracy,fitness,selectedCount,elapsed};
    for index = 1:numel(metricNames)
        results.(['Mean_' metricNames{index}])(datasetIndex,:) = mean(measurements{index},1);
        results.(['Std_' metricNames{index}])(datasetIndex,:) = std(measurements{index},0,1);
    end
    for algorithmIndex = settings.algorithmIndices
        curves = reshape(results.Curves(datasetIndex,:,algorithmIndex),1,[]);
        lengths = cellfun(@numel,curves);
        assert(all(lengths==lengths(1)), ...
            'publicfs:CurveLength','Native curve lengths differ between repeated runs.');
        results.MeanCurves{datasetIndex,algorithmIndex} = mean(vertcat(curves{:}),1);
    end
    if settings.makePlots
        plot_fs_convergence(results.MeanCurves(datasetIndex,:), ...
            algorithmNames,entry.PaperID,entry.Name);
    end
    if settings.saveResults
        resultFile = fullfile(settings.outputDirectory,'feature_selection_results.mat');
        % Keep the temporary path shorter than the final results path.
        [~,temporaryName] = fileparts(tempname(settings.outputDirectory));
        temporaryName = strrep(temporaryName,'_','');
        temporaryName = temporaryName(1:min(20,numel(temporaryName)));
        temporaryFile = fullfile(settings.outputDirectory,[temporaryName '.mat']);
        save(temporaryFile,'results','-v7.3');
        movefile(temporaryFile,resultFile,'f');
        fprintf('Saved completed datasets to %s\n',settings.outputDirectory);
    end
    clear model acoOptions source A feat label
end
fprintf('\nFeature-selection experiments completed.\n');
end

function datasets = paper_datasets()
% Dataset order and dimensions for manuscript Table 6. Labels are last.
originalIDs = [1 4 5 6 7 13 23 27 34 37 52 57 59 65 69 71 72 74];
names = ["Adenocarcinoma","warpPIE10P","BrainTumor1","BrainTumor2", ...
    "Breast3","Cancer","DrivFace","GLI85","Leukemia1","Lung Cancer", ...
    "penglymp","Prostate GE","Prostate6033","SMK CAN 187", ...
    "TOX 171","Tumors 9","Tumors 11","warpAR10P"];
files = ["Adenocarcinoma.mat","warpPIE10P.mat","Brain_Tumor1.mat", ...
    "Brain_Tumor2.mat","Breast3.mat","cancer.mat","drivFace.mat", ...
    "GLI_85.mat","Leukemia1.mat","Lung_Cancer.mat","penglymp.mat", ...
    "Prostate_GE.mat","Prostate6033.mat","SMK_CAN_187.mat", ...
    "TOX_171.mat","Tumors_9.mat","Tumors_11.mat","warpAR10P.mat"];
featureCounts = [9672 2420 5920 10367 4869 12600 6400 22283 5327 12600 4026 5966 6033 19993 5748 5726 12533 2400];
instanceCounts = [76 210 90 50 95 203 606 85 72 203 96 102 102 187 171 60 174 130];
classCounts = [2 10 5 4 3 4 3 2 3 5 9 2 2 2 4 9 11 10];
datasets = table(("L" + (1:18))',originalIDs',names',files', ...
    featureCounts',instanceCounts',classCounts', ...
    'VariableNames',{'PaperID','HistoricalIndex','Name','File', ...
    'ExpectedFeatures','ExpectedInstances','ExpectedClasses'});
end
