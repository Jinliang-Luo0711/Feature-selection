function statistics = analyze_fs_results(results)
% Apply the original Friedman and Wilcoxon rank-sum procedures to new runs.
rows = results.Settings.datasetIndices;
algorithms = results.Settings.algorithmIndices;
assert(numel(rows)>=2 && numel(algorithms)>=2, ...
    'publicfs:Statistics','Select at least two datasets and two algorithms.');
names = results.AlgorithmNames(algorithms);
measurements = {'Fitness','Acc','Nf','Time'};
statistics = struct;
statistics.AlgorithmNames = names;
statistics.PaperIDs = results.Datasets.PaperID(rows);
for index = 1:numel(measurements)
    values = results.(['Mean_' measurements{index}])(rows,algorithms);
    assert(all(isfinite(values),'all'),'publicfs:Statistics','Incomplete experiment results.');
    % Negating accuracy makes smaller Friedman ranks consistently preferable.
    if strcmp(measurements{index},'Acc')
        values = -values;
    end
    [p,tableOutput,details] = friedman(values,1,'off');
    statistics.(measurements{index}) = struct('PValue',p, ...
        'Table',{tableOutput},'MeanRanks',details.meanranks);
end
baseline = 2;
assert(ismember(baseline,algorithms), ...
    'publicfs:Statistics','MIDLMt-OOA must be present for the original baseline comparison.');
comparisons = algorithms(algorithms~=baseline);
pValues = nan(numel(rows),numel(comparisons));
for rowIndex = 1:numel(rows)
    values = results.Cdata_Fitnsss{rows(rowIndex)};
    for comparisonIndex = 1:numel(comparisons)
        pValues(rowIndex,comparisonIndex) = ...
            ranksum(values(:,baseline),values(:,comparisons(comparisonIndex)));
    end
end
statistics.Wilcoxon = struct('Baseline','MIDLMt-OOA', ...
    'Comparisons',{results.AlgorithmNames(comparisons)},'PValues',pValues);
end
