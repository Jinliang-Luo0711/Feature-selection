% �����Ż��㷨(Arithmetic Optimization Algorithm, AOA)2021
function [Scorebest,Acc,Nf,Sf,Convergence_curve,dt] = AOA2021(feat,label,Materials_no,Max_iter,HO)
% Initialization
tic;
fobj = @jFitnessFunction;
dim = size(feat,2); 
lb = 0;
ub = 1;
C1=2;C2=6;C3=1;C4=2;
thres = 0.5;
u=.9;l=.1;   %paramters in Eq. (12)
X=lb+rand(Materials_no,dim)*(ub-lb);%initial positions Eq. (4)
den=rand(Materials_no,dim); % Eq. (5)
vol=rand(Materials_no,dim);
acc=lb+rand(Materials_no,dim)*(ub-lb);% Eq. (6)
for i=1:Materials_no
    Y(i) = fobj(feat,label,(X(i,:) > thres),HO);
%     Y(i)=fobj(X(i,:));
end
[Scorebest, Score_index] = min(Y);
Xbest = X(Score_index,:);
den_best=den(Score_index,:);
vol_best=vol(Score_index,:);
acc_best=acc(Score_index,:);
acc_norm=acc;
for t = 1:Max_iter
    TF=exp(((t-Max_iter)/(Max_iter)));   % Eq. (8)
    if TF>1
        TF=1;
    end
    d=exp((Max_iter-t)/Max_iter)-(t/Max_iter); % Eq. (9)
    acc=acc_norm;
    r=rand();
    for i=1:Materials_no
        den(i,:)=den(i,:)+r*(den_best-den(i,:));   % Eq. (7)
        vol(i,:)=vol(i,:)+r*(vol_best-vol(i,:));
        if TF<.45%collision
            mr=randi(Materials_no);
            acc_temp(i,:)=(den(mr,:)+(vol(mr,:).*acc(mr,:)))./(rand*den(i,:).*vol(i,:));   % Eq. (10)
        else
            acc_temp(i,:)=(den_best+(vol_best.*acc_best))./(rand*den(i,:).*vol(i,:));   % Eq. (11)
        end
    end
    
    acc_norm=((u*(acc_temp-min(acc_temp(:))))./(max(acc_temp(:))-min(acc_temp(:))))+l;   % Eq. (12)
    
    for i=1:Materials_no
        if TF<.4
            for j=1:size(X,2)
                mrand=randi(Materials_no);
                Xnew(i,j)=X(i,j)+C1*rand*acc_norm(i,j).*(X(mrand,j)-X(i,j))*d;  % Eq. (13)
            end
        else
            for j=1:size(X,2)
                p=2*rand-C4;  % Eq. (15)
                T=C3*TF;
                if T>1
                    T=1;
                end
                if p<.5
                    Xnew(i,j)=Xbest(j)+C2*rand*acc_norm(i,j).*(T*Xbest(j)-X(i,j))*d;  % Eq. (14)
                else
                    Xnew(i,j)=Xbest(j)-C2*rand*acc_norm(i,j).*(T*Xbest(j)-X(i,j))*d;
                end
            end
        end
    end
    
    Xnew=fun_checkpositions(dim,Xnew,Materials_no,lb,ub);
    for i=1:Materials_no
%         v=fobj( Xnew(i,:));
        v = fobj(feat,label,(Xnew(i,:) > thres),HO);
        if v<Y(i)
            X(i,:)=Xnew(i,:);
            Y (i)=v;
        end
        
    end
    [var_Ybest,var_index] = min(Y);
    Convergence_curve(t)=var_Ybest;
    fprintf('\nIteration %d Best (AOA)= %f',t,Convergence_curve(t))
    if var_Ybest<Scorebest
        Scorebest=var_Ybest;
        Score_index=var_index;
        Xbest = X(var_index,:);
        den_best=den(Score_index,:);
        vol_best=vol(Score_index,:);
        acc_best=acc_norm(Score_index,:);
    end
    
end
Pos   = 1:dim; 
Sf    = Pos((Xbest > thres) == 1);
% Store results
Nf = length(Sf);
Acc = 1-(var_Ybest-0.01*(Nf/dim))/0.99;
% Acc = FitFunc(feat,label,Xbest > thres,HO);
dt = toc;
end

function vec_pos=fun_checkpositions(dim,vec_pos,var_no_group,lb,ub)
Lb=lb*ones(1,dim);
Ub=ub*ones(1,dim);
for i=1:var_no_group
    isBelow1 = vec_pos(i,:) < Lb;
    isAboveMax = (vec_pos(i,:) > Ub);
    if isBelow1 == true
        vec_pos(i,:) =Lb;
    elseif find(isAboveMax== true)
        vec_pos(i,:) = Ub;
    end
end
end


