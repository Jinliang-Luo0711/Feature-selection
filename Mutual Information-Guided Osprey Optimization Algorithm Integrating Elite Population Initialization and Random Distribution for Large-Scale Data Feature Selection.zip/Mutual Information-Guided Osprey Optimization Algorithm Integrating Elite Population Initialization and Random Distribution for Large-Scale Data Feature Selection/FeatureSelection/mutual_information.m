
function mi_scores = mutual_information(X, y)
% 计算特征与目标变量的互信息
[~, n_features] = size(X);
mi_scores = zeros(1, n_features);

for feature_idx = 1:n_features
    feature = X(:, feature_idx);
    unique_feature = unique(feature);
    unique_y = unique(y);
    
    % 计算联合概率分布
    joint_prob = zeros(length(unique_feature), length(unique_y));
    for i = 1:length(unique_feature)
        for j = 1:length(unique_y)
            joint_prob(i, j) = sum((feature == unique_feature(i)) & (y == unique_y(j)));
        end
    end
    joint_prob = joint_prob / sum(joint_prob(:)); % 归一化联合概率分布
    
    % 计算特征的边缘概率分布
    feature_prob = sum(joint_prob, 2);
    
    % 计算目标变量的边缘概率分布
    y_prob = sum(joint_prob, 1);
    
    % 计算互信息
    mi = 0;
    for i = 1:length(unique_feature)
        for j = 1:length(unique_y)
            if joint_prob(i, j) > 0
                mi = mi + joint_prob(i, j) * log2(joint_prob(i, j) / (feature_prob(i) * y_prob(j)));
            end
        end
    end
    mi_scores(feature_idx) = mi;
end

end