



%%% Designed and Developed by Pavel Trojovský and Mohammad Dehghani %%%


% function[Best_score,Best_pos,OOA_curve]=OOA(SearchAgents,Max_iterations,lowerbound,upperbound,dimension,fitness,num)
function[Best_score,Acc,Nf,Sf,OOA_curve,dt]=IIOOA_t_MI(feat,label,SearchAgents,Max_iterations,HO)
% Initialization
tic;
fobj = @jFitnessFunction;
dimension = size(feat,2); 
lowerbound = 0;
upperbound = 1;
thres = 0.5;

% MI互信息算法引导
index_rem = mutual_information(feat, label);
index_rem = (index_rem - min(index_rem)) / (max(index_rem) - min(index_rem) + eps);  % 避免除0
Xv  = ones(1,dimension);
% ==== 新增：扰动失败计数器 ====
freeze_count = zeros(SearchAgents, dimension); % 每个个体每个特征的扰动失败计数
rng(mod(sum(100 * clock), 2^32)); 
% 结束
% 构建特征矩阵
add_index = zeros(SearchAgents, dimension);
delete_index = zeros(SearchAgents, dimension);

lowerbound=ones(1,dimension).*(lowerbound);                              % Lower limit for variables
upperbound=ones(1,dimension).*(upperbound);                              % Upper limit for variables

%% INITIALIZATION
% for i=1:dimension
%     X(:,i) = lowerbound(i)+rand(SearchAgents,1).*(upperbound(i) - lowerbound(i));                          % Initial population
% end

%% 方法1：常规随机初始化（共享基础种群）
X_random = zeros(SearchAgents, dimension);
for i = 1:dimension
    X_random(:,i) = lowerbound(i) + rand(SearchAgents,1) .* (upperbound(i) - lowerbound(i));
end

%% 方法2：基本反向学习初始化（基于X_random）
X_opp_basic_rev = zeros(SearchAgents, dimension);
for i = 1:dimension
    X_opp_basic_rev(:,i) = lowerbound(i) + upperbound(i) - X_random(:,i);  % 直接基于X_random计算
end

%% 方法3：基于群体中心的引力反向学习初始化（基于X_random）
% 计算种群中心
population_center = mean(X_random);

% 计算引力反向种群
X_opp_grav = zeros(SearchAgents, dimension);
for i = 1:dimension
    % 初始化阶段使用固定引力因子
    gravity_factor = 0.5;
    
    for j = 1:SearchAgents
        % 计算个体到中心的距离
        distance_to_center = abs(X_random(j,i) - population_center(i));
        
        % 基于引力的反向点生成
        if X_random(j,i) <= population_center(i)
            X_opp_grav(j,i) = upperbound(i) + population_center(i) - X_random(j,i) ...
                           + gravity_factor * distance_to_center;
        else
            X_opp_grav(j,i) = lowerbound(i) + population_center(i) - X_random(j,i) ...
                           - gravity_factor * distance_to_center;
        end
        
        % 边界处理
        X_opp_grav(j,i) = min(max(X_opp_grav(j,i), lowerbound(i)), upperbound(i));
    end
end

%% 合并三种初始化方法的结果并选择最优个体
% 合并所有生成的种群（减少到3种：随机解+基本反向解+引力反向解）
combined_pop = [X_random; X_opp_basic_rev; X_opp_grav];  % 共3*SearchAgents个个体

% 计算适应度
total_agents = 3 * SearchAgents;
fitness_values = zeros(total_agents, 1);
for i = 1:total_agents
    % fitness_values(i) = fitness(combined_pop(i,:)', num);
    fitness_values(i) = fobj(feat,label,(combined_pop(i,:)> thres), HO);
end

% 按适应度排序并选择最优的SearchAgents个个体
[~, sorted_idx] = sort(fitness_values);
X = combined_pop(sorted_idx(1:SearchAgents), :);  % 最终选择的基础种群

% 求平均位置
Mean_X = mean(X); 
% 结束

for i =1:SearchAgents
    L=X(i,:);
    fit(i)=fobj(feat,label,(L > thres),HO);
end
%%

for t=1:Max_iterations  % algorithm iteration
    
    %%  update: BEST proposed solution
    [Fbest , blocation]=min(fit);
    
    if t==1
        xbest=X(blocation,:);                                           % Optimal location
        fbest=Fbest;                                           % The optimization objective function
    elseif Fbest<fbest
        fbest=Fbest;
        xbest=X(blocation,:);
    end
    %%
    %%
    for i=1:SearchAgents
        %% Phase 1: : POSITION IDENTIFICATION AND HUNTING THE FISH (EXPLORATION)
        fish_position=find(fit<fit(i));% Eq(4)
        r1=rand();
        if size(fish_position,2)==0
            selected_fish=xbest;
        else
            % 原始算法
            % if r1<0.5
            %     selected_fish=xbest;
            % else
            %     k=randperm(size(fish_position,2),1);
            %     selected_fish=X(fish_position(k));
            % end
            % 原始算法

            if r1<0.5
                selected_fish=xbest;
            elseif r1<0.75
                selected_fish=Mean_X;
            else
                k=randperm(size(fish_position,2),1);
                selected_fish=X(fish_position(k));
            end
        end
        
        % 加入t分布
        nu = 3;  % 自由度参数，可根据需要调整
        Z = randn(SearchAgents, dimension);
        Y = chi2rnd(nu, SearchAgents, dimension);
        tD = 0.1 * abs(Z ./ sqrt(Y/nu));  % 调整比例因子与正态分布保持一致
        % 结束

        I=round(1+rand);

        % 原始算法计算公式
        % X_new_P1=X(i,:)+rand(1,1).*(selected_fish-I.*X(i,:));%Eq(5)
        % 结束

        X_new_P1=X(i,:)+tD(i,:).*(selected_fish-I.*X(i,:));%Eq(5)
        X_new_P1 = max(X_new_P1,lowerbound);X_new_P1 = min(X_new_P1,upperbound);
        
        % update position based on Eq (6)
        L=X_new_P1;
        fit_new_P1=fobj(feat,label,(L > thres),HO);
        if fit_new_P1<fit(i)
            X(i,:) = X_new_P1;
            fit(i) = fit_new_P1;
        end
        %% END Phase 1
        
        %%
        %% PHASE 2: CARRYING THE FISH TO THE SUITABLE POSITION (EXPLOITATION)
        X_new_P1=X(i,:)+(lowerbound+rand*(upperbound-lowerbound))/t;%Eq(7)
        X_new_P1 = max(X_new_P1,lowerbound);X_new_P1 = min(X_new_P1,upperbound);
        % update position based on Eq (8)
        L=X_new_P1;
        fit_new_P1=fobj(feat,label,(L > thres),HO);
        if fit_new_P1<fit(i)
            X(i,:) = X_new_P1;
            fit(i) = fit_new_P1;
        end
        %% END Phase 2
        %%
    end
    %%
    
if mod(t, 2) == 0
    % === 添加操作 ===
    for i = 1:SearchAgents
        bin_vec = X(i,:) > thres;
        selectF = ((Xv - bin_vec) > 0.5) .* index_rem;

        % 忽略之前已经尝试添加过的特征
        selectF(add_index(i,:) == 1) = 0;

        % 新增：过滤冻结特征
        selectF(freeze_count(i,:) >= 3) = 0;

        [~, sorted_indices] = sort(selectF, 'descend');
        if isempty(sorted_indices) || all(selectF == 0)
            continue;
        end

        % 选择扰动目标：最优、次优、第三优
        candidates = sorted_indices(1:min(3, numel(sorted_indices)));
        nCand = numel(candidates);

        r = rand;
        if r < 0.5 || nCand == 1
            select_index = candidates(1);       % 50% 选择最优特征
        elseif r < 0.8 || nCand == 2
            select_index = candidates(2);       % 30% 选择次优特征
        else
            select_index = candidates(3);       % 20% 选择第三优特征
        end

        inter = bin_vec;
        inter(select_index) = 1;

        fit_inter = fobj(feat,label,inter,HO);
        if fit_inter < fbest
            fbest = fit_inter;
            xbest = inter;
            freeze_count(i, select_index) = 0;  % 成功则清零
        else
            add_index(i, select_index) = 1;
            freeze_count(i, select_index) = freeze_count(i, select_index) + 1;
        end
    end

else
    % === 删除操作 ===
    for i = 1:SearchAgents
        bin_vec = X(i,:) > thres;
        selectF = bin_vec .* index_rem;
        selectF(selectF == 0) = inf;

        % 忽略已经删除过的 & 冻结过的特征
        selectF(delete_index(i,:) == 1) = inf;
        selectF(freeze_count(i,:) >= 3) = inf;

        [~, sorted_indices] = sort(selectF, 'ascend');
        if isempty(sorted_indices) || all(selectF == inf)
            continue;
        end

        % 选择扰动目标：最差、次差、第三差
        candidates = sorted_indices(1:min(3, numel(sorted_indices)));
        nCand = numel(candidates);

        r = rand;
        if r < 0.5 || nCand == 1
            select_index = candidates(1);       % 50% 剔除最差特征
        elseif r < 0.8 || nCand == 2
            select_index = candidates(2);       % 30% 剔除次差特征
        else
            select_index = candidates(3);       % 20% 剔除第三差特征
        end

        inter = bin_vec;
        inter(select_index) = 0;

        fit_inter = fobj(feat,label,inter,HO);
        if fit_inter < fbest
            fbest = fit_inter;
            xbest = inter;
            freeze_count(i, select_index) = 0;
        else
            delete_index(i, select_index) = 1;
            freeze_count(i, select_index) = freeze_count(i, select_index) + 1;
        end
    end
end

    % ==== 每隔 20 轮清空一次 freeze_count ====
if mod(t, 20) == 0
    freeze_count = zeros(SearchAgents, dimension); % 清空所有个体所有特征的冻结状态
end

    best_so_far(t)=fbest;
%     average(t) = mean (fit);
    fprintf('\nIteration %d Best (MIDLMt-OOA)= %f',t,best_so_far(t))
    
end
Best_score=fbest;
OOA_curve=best_so_far;

Pos   = 1:dimension; 
Sf    = Pos((xbest > thres) == 1);
% Store results
Nf = length(Sf);
Acc = 1-(fbest-0.01*(Nf/dimension))/0.99;
% Acc = FitFunc(feat,label,Xbest > thres,HO);
dt = toc;
end

