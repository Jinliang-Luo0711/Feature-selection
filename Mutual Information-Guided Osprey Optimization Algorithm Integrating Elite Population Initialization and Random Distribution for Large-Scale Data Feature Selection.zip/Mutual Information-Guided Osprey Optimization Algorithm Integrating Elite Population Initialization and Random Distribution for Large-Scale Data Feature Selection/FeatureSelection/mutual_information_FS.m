function [prodata, remdata, mi_scores] = mutual_information_FS(data, label)

% === Step 1: 计算互信息 ===
mi_scores = mutual_information(data, label);

% === Step 2: 降序排序特征索引 ===
[~, ranks] = sort(mi_scores, 'descend');

% === Step 3: 使用膝点法确定重要特征数量 ===
maxpoint = [1, mi_scores(ranks(1))];
minpoint = [length(ranks), mi_scores(ranks(end))];
maxDistance = 0;
% kneepoint = 0;
kneepoint = 1;

for i = 1:length(ranks)
    point = [i, mi_scores(ranks(i))];
    d = abs(det([minpoint - maxpoint; point - maxpoint])) / norm(minpoint - maxpoint);
    if d > maxDistance
        maxDistance = d;
        kneepoint = i;
    end
end

% === Step 4: 膝点分割特征 ===
prodata = ranks(1:kneepoint);
remdata = ranks(kneepoint+1:end);

% === Step 5: 可视化互信息排名与膝点 ===
% figure;
% plot(1:length(mi_scores), mi_scores(ranks), '-o');
% hold on;
% plot(kneepoint, mi_scores(ranks(kneepoint)), 'r*', 'MarkerSize', 10);
% title('Mutual Information 特征权重与膝点分割');
% xlabel('特征排名');
% ylabel('互信息得分');
% legend('互信息', '膝点');
% grid on;

end
