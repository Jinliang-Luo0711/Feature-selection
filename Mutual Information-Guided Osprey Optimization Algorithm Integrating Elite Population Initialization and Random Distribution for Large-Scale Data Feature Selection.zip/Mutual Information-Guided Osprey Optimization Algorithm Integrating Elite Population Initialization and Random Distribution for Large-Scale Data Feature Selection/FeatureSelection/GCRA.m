%_________________________________________________________________________%
% Greater Cane Rat Algorithm (GCRA)                                       %
%                                                                         %
%  Developed in MATLAB R2020b                                             %
%                                                                         %
%  Designed and Developed: Dr. Ovre Agushaka                              %
%                                                                         %
%         E-Mail: jo.agushaka@science.edu.ng                              %
%                 jefshak@gmail.com                                       %
%                                                                         %
%                                  
%                                                                         %
%  Published paper: Agushaka et al.                                       %
%          A novel algorithm for global optimization: Greater cane rat    %
%          algorithm                                                      %
%_________________________________________________________________________%

% function[Score,Position,Convergence]=GCRA_CEC2022(Search_Agents,Max_iterations,Lower_bound,Upper_bound,dimension,objective)
% function[Score,Position,Convergence]=GCRA(Search_Agents,Max_iterations,Lower_bound,Upper_bound,dimension,objective,num)
function[Score,Acc,Nf,Sf,Convergence,dt]=GCRA(feat,label,Search_Agents,Max_iterations,HO)
% function [Scorebest,Acc,Nf,Sf,Convergence_curve,dt] = AOA2021(feat,label,Materials_no,Max_iter,HO)
tic;
fobj = @jFitnessFunction;
dim = size(feat,2); 
Lower_bound = 0;
Upper_bound = 1;
thres = 0.5;

Position=zeros(1,dim);
Score=inf; 
% Alpha_pos=zeros(1,dimension);
% Alpha_score=inf; 

Gcanerats=GCRA_init(Search_Agents,dim,Upper_bound,Lower_bound);
Convergence=zeros(1,Max_iterations);
l=1;
for i=1:size(Gcanerats,1)  
        
        Flag4Upper_bound=Gcanerats(i,:)>Upper_bound;
        Flag4Lower_bound=Gcanerats(i,:)<Lower_bound;
        Gcanerats(i,:)=(Gcanerats(i,:).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               
        
        % fitness=fobj(Gcanerats(i,:)',num);
        fitness=fobj(feat,label,(Gcanerats(i,:)> thres),HO);
        
        if fitness<Score 
            Score=fitness; 
            Position=Gcanerats(i,:);
            Alpha_pos1=Position;
            Alpha_score=Score;
        end
        
 end

while l<Max_iterations+1
    Alpha_pos=max(Alpha_pos1);
%     Alpha_pos=Alpha_pos1(nn);
   GR_m=randperm(Search_Agents-1,1); 
   GR_rho=0.5;
   GR_r= Alpha_score-l*(Alpha_score/Max_iterations);
    x = 1;
    y = 4;
    GR_mu = floor((y-x).*rand(1,1) + x);
    GR_c=rand;
    GR_alpha=2*GR_r*rand-GR_r;
    GR_beta=2*GR_r*GR_mu-GR_r;
    
    for i=1:size(Gcanerats,1)
        for j=1:size(Gcanerats,2)  
            Gcanerats(i,j)= (Gcanerats(i,j)+Alpha_pos)/2; 
        end
    end
    for i=1:size(Gcanerats,1)
        for j=1:size(Gcanerats,2)  
           if rand<GR_rho
%                  dd=Alpha_pos;
                 Gcanerats(i,j)= Gcanerats(i,j)+GR_c*(Alpha_pos-GR_r*Gcanerats(i,j)); 
                 Flag4Upper_bound=Gcanerats(i,j)>Upper_bound;
                 Flag4Lower_bound=Gcanerats(i,j)<Lower_bound;
                 Gcanerats(i,j)=(Gcanerats(i,j).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               
        
%                  fitness=objective(Gcanerats(i,j)',num);
                 fitness=fobj(feat,label,(Gcanerats(i,:)> thres),HO);
                 
                  if fitness<Score 
                        Score=fitness; 
                        Position=Gcanerats(i,j);
                  else
                      Gcanerats(i,j)= Gcanerats(i,j)+GR_c*(Gcanerats(i,j)-GR_alpha*Alpha_pos); 
                      Flag4Upper_bound=Gcanerats(i,j)>Upper_bound;
                      Flag4Lower_bound=Gcanerats(i,j)<Lower_bound;
                      Gcanerats(i,j)=(Gcanerats(i,j).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               

                       fitness=fobj(feat,label,(Gcanerats(i,:)> thres),HO);
                      if fitness<Score 
                            Score=fitness; 
                            Position=Gcanerats(i,j);
                      end
                  end
            else
                
                 Gcanerats(i,j)= Gcanerats(i,j)+GR_c*(Alpha_pos-GR_mu*Gcanerats(GR_m,j));
                 Flag4Upper_bound=Gcanerats(i,j)>Upper_bound;
                 Flag4Lower_bound=Gcanerats(i,j)<Lower_bound;
                 Gcanerats(i,j)=(Gcanerats(i,j).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               
        
                 fitness=fobj(feat,label,(Gcanerats(i,:)> thres),HO);
                  if fitness<Score 
                        Score=fitness; 
                        Position=Gcanerats(i,j);
                  else
                      Gcanerats(i,j)= Gcanerats(i,j)+GR_c*(Gcanerats(GR_m,j)-GR_beta*Alpha_pos); 
                      Flag4Upper_bound=Gcanerats(i,j)>Upper_bound;
                      Flag4Lower_bound=Gcanerats(i,j)<Lower_bound;
                      Gcanerats(i,j)=(Gcanerats(i,j).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               

                      fitness=fobj(feat,label,(Gcanerats(i,:)> thres),HO);
                      if fitness<Score 
                            Score=fitness; 
                            Position=Gcanerats(i,j);
                      end
                  end
            end
            Alpha_pos1=Position;
            Alpha_score=Score;    
                        
        end
    end
    Convergence(l)=Score;
    fprintf('\nIteration %d Best (GCRA)= %f',l,Convergence(l))
    l=l+1;    
%     Convergence(l)=Score;原始算法放在了后面
end
Pos   = 1:dim; 
Sf    = Pos((Position > thres) == 1);
% Store results
Nf = length(Sf);
Acc = 1-(Score-0.01*(Nf/dim))/0.99;
% Acc = FitFunc(feat,label,Xbest > thres,HO);
dt = toc;
end
