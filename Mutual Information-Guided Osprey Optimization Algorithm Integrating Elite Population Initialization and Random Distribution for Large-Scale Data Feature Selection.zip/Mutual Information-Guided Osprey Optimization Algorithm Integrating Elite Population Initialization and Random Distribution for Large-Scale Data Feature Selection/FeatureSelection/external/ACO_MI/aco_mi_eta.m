function eta=aco_mi_eta(model,candidates,lastSelected)
% Equation 7, with the explicitly declared last-selected feature reference.
eta=zeros(size(candidates));
if isfield(model,'etaMatrix')
    eta=reshape(model.etaMatrix(candidates,lastSelected),size(candidates));
    return;
end
u=model.patternID(lastSelected);
if ~isempty(model.pairMatrix)
    raw=reshape(model.pairMatrix(model.patternID(candidates),u),size(candidates));
    FFMI=aco_mi_eidar(raw,model.globalMin,model.globalMax,model.m);
    eta=(model.CFMI(candidates)-FFMI+model.m)/(2*model.m-1);
    return;
end
for j=1:numel(candidates)
    v=model.patternID(candidates(j));
    if ~isempty(model.pairMatrix)
        raw=model.pairMatrix(v,u);
    else
        key=sprintf('%d_%d',min(u,v),max(u,v));
        if isKey(model.lazyPairCache,key)
            raw=model.lazyPairCache(key);
        else
            raw=aco_mi_discrete_mi(model.patterns(:,u),model.patterns(:,v));
            model.lazyPairCache(key)=raw;
        end
    end
    FFMI=aco_mi_eidar(raw,model.globalMin,model.globalMax,model.m);
    eta(j)=(model.CFMI(candidates(j))-FFMI+model.m)/(2*model.m-1);
end
assert(all(eta>0 & eta<=1));
end
