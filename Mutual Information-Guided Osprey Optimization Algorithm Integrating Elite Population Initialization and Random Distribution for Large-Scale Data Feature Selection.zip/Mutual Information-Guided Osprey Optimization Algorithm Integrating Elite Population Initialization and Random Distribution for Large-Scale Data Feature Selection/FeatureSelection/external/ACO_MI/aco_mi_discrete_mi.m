function value=aco_mi_discrete_mi(x,y)
% Ordinary empirical mutual information, in bits; neither NMI nor CMI.
[~,~,x]=unique(x(:)); [~,~,y]=unique(y(:));
joint=accumarray([x y],1,[max(x) max(y)]); joint=joint/sum(joint,'all');
product=sum(joint,2)*sum(joint,1);
positive=joint>0;
value=sum(joint(positive).*log2(joint(positive)./product(positive)));
value=max(0,value); % suppress negative round-off only
end
