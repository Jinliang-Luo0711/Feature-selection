function [B,model]=aco_mi_mdl(X,y,model)
% Fayyad-Irani 1993 supervised MDL recursive entropy discretization.
% Fit only on supplied training data; no quantile discretization is used.
X=double(X); [n,D]=size(X);
if nargin<3
    assert(numel(y)==n && n>=2);
    [~,~,labels]=unique(y(:)); C=max(labels);
    medians=median(X,1,'omitnan'); medians(~isfinite(medians))=0;
    cuts=cell(1,D); B=zeros(n,D,'uint16');
    for j=1:D
        x=X(:,j); x(~isfinite(x))=medians(j);
        [sx,ord]=sort(x); sy=labels(ord);
        cuts{j}=findCuts(sx,sy,C);
        B(:,j)=uint16(discretize(x,[-Inf cuts{j} Inf]));
    end
    model=struct('method',"Fayyad_Irani_1993_MDL",'cuts',{cuts}, ...
        'missingMedians',medians,'trainingRows',n,'featureCount',D, ...
        'candidateRule',"all_distinct_value_boundaries", ...
        'cutTieRule',"smallest_cut",'acceptance',"gain_strictly_above_MDL_threshold");
else
    assert(D==model.featureCount);
    B=zeros(n,D,'uint16');
    for j=1:D
        x=X(:,j); x(~isfinite(x))=model.missingMedians(j);
        B(:,j)=uint16(discretize(x,[-Inf model.cuts{j} Inf]));
    end
end
end

function cuts=findCuts(x,y,C)
N=numel(x); cuts=[];
if N<2 || x(1)==x(end) || numel(unique(y))<2, return; end
candidates=find(x(1:end-1)<x(2:end));
if isempty(candidates), return; end
counts=cumsum(full(sparse((1:N)',y,1,N,C)),1);
total=counts(end,:); H=entropyCounts(total);
left=counts(candidates,:); right=total-left;
nl=candidates; nr=N-candidates;
HL=entropyRows(left); HR=entropyRows(right);
weighted=(nl.*HL+nr.*HR)/N;
[~,best]=min(weighted); cutIndex=candidates(best);
gain=H-weighted(best);
k=sum(total>0); k1=sum(left(best,:)>0); k2=sum(right(best,:)>0);
delta=log2(3^k-2)-(k*H-k1*HL(best)-k2*HR(best));
threshold=(log2(N-1)+delta)/N;
if gain>threshold
    cut=x(cutIndex)+(x(cutIndex+1)-x(cutIndex))/2;
    if cut>=x(cutIndex+1), cut=x(cutIndex); end
    cuts=[findCuts(x(1:cutIndex),y(1:cutIndex),C),cut, ...
        findCuts(x(cutIndex+1:end),y(cutIndex+1:end),C)];
end
end

function h=entropyCounts(counts)
p=counts/sum(counts); nz=p>0; h=-sum(p(nz).*log2(p(nz)));
end
function h=entropyRows(counts)
p=counts./sum(counts,2); term=zeros(size(p)); nz=p>0;
term(nz)=p(nz).*log2(p(nz)); h=-sum(term,2);
end
