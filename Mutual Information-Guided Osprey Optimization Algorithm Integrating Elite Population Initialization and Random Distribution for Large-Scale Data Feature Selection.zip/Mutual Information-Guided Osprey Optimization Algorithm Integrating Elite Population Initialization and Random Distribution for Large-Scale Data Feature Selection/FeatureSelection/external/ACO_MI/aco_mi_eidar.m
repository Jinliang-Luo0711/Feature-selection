function rank=aco_mi_eidar(values,a,b,m)
% Algorithm 1 bins: width (b-a)/(m-1), ranks 1..m, NOT (b-a)/m.
if m==1 || b==a
    rank=ones(size(values)); return;
end
width=(b-a)/(m-1);
scaled=(values-a)/width;
nearest=round(scaled);
close=abs(scaled-nearest)<=16*eps(max(1,abs(scaled)));
scaled(close)=nearest(close);
rank=min(m,max(1,floor(scaled)+1));
end
