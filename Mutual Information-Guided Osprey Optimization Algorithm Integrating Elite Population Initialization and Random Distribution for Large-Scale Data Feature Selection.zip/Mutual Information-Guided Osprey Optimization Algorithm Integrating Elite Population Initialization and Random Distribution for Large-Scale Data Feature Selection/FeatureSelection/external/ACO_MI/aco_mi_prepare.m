function model=aco_mi_prepare(Xtrain,ytrain,options)
% Exact global EIDAR extrema across retained CFMI and off-diagonal FFMI.
% MI-equivalent categorical columns are compressed without approximation.
start=tic; [B,mdl]=aco_mi_mdl(Xtrain,ytrain); D=size(B,2);
CF=zeros(1,D);
for j=1:D, CF(j)=aco_mi_discrete_mi(B(:,j),ytrain); end
retained=find(CF>options.delta);
publicationRetainedCount=numel(retained);
pilotCapped=isfinite(options.pilotFeatureCap) && numel(retained)>options.pilotFeatureCap;
if pilotCapped
    [~,order]=sort(CF(retained),'descend');
    retained=retained(order(1:options.pilotFeatureCap));
end
if isempty(options.originalFeatureCount), m=D; else, m=options.originalFeatureCount; end
p=numel(retained);
if p==0
    model=struct('retained',retained,'m',m,'p',0,'rawCF',CF,'mdl',mdl, ...
        'publicationRetainedCount',publicationRetainedCount,'pilotCapped',pilotCapped, ...
        'preparationSeconds',toc(start),'pairComputations',0); return;
end
Z=B(:,retained); canonical=zeros(size(Z),'uint16');
for j=1:p
    [~,~,codes]=unique(Z(:,j),'stable'); canonical(:,j)=uint16(codes);
end
[uniquePatterns,~,patternID]=unique(canonical','rows','stable');
patterns=uniquePatterns'; U=size(patterns,2);
multiplicity=accumarray(patternID,1,[U 1]);
uniquePairCount=U*(U-1)/2;
assert(uniquePairCount<=options.maxExactPairs,'acomi:ExactPairBudget', ...
    ['Exact global EIDAR extrema require %g distinct pair evaluations after compression. ' ...
    'Increase maxExactPairs explicitly or use a labelled pilotFeatureCap; no silent approximation is made.'],uniquePairCount);
a=min(CF(retained)); b=max(CF(retained));
if U<=options.maxCachedPatterns, cache=NaN(U,U); else, cache=[]; end
pairComputations=0;
if ~isempty(cache)
    cache=aco_mi_pair_cache(patterns);
    diagonalIndex=1:U+1:U*U; diagonal=cache(diagonalIndex);
    cache(diagonalIndex)=Inf; a=min(a,min(cache,[],'all'));
    cache(diagonalIndex)=-Inf; b=max(b,max(cache,[],'all'));
    cache(diagonalIndex)=diagonal;
    if any(multiplicity>1)
        repeated=diagonal(multiplicity>1);
        a=min(a,min(repeated));b=max(b,max(repeated));
    end
    pairComputations=uniquePairCount;
else
for i=1:U
    if multiplicity(i)>1
        % Different original features can have identical partitions; their
        % off-diagonal MI is H(pattern) and belongs to the publication's X.
        selfMI=aco_mi_discrete_mi(patterns(:,i),patterns(:,i));
        a=min(a,selfMI); b=max(b,selfMI);
    end
    if ~isempty(cache), cache(i,i)=aco_mi_discrete_mi(patterns(:,i),patterns(:,i)); end
    for j=i+1:U
        value=aco_mi_discrete_mi(patterns(:,i),patterns(:,j)); pairComputations=pairComputations+1;
        a=min(a,value); b=max(b,value);
        if ~isempty(cache), cache(i,j)=value; cache(j,i)=value; end
    end
end
end
model=struct('retained',retained,'m',m,'p',p,'rawCF',CF,'mdl',mdl, ...
    'publicationRetainedCount',publicationRetainedCount,'pilotCapped',pilotCapped, ...
    'patterns',patterns,'patternID',patternID,'multiplicity',multiplicity, ...
    'pairMatrix',cache,'lazyPairCache',containers.Map('KeyType','char','ValueType','double'), ...
    'globalMin',a,'globalMax',b,'CFMI',aco_mi_eidar(CF(retained),a,b,m), ...
    'pairComputations',pairComputations,'uniquePatterns',U,'preparationSeconds',toc(start));
if ~isempty(cache)
    FF=aco_mi_eidar(cache(patternID,patternID),a,b,m);
    model.etaMatrix=(model.CFMI(:)-FF+m)/(2*m-1);
end
model.preparationSeconds=toc(start);
end
