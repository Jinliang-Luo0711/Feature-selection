function result=aco_mi_reproduce(objective,Xtrain,ytrain,options)
% Independently implemented ACO-MI with declared interpretations of underspecified steps.
% objective(mask) must return [commonCost, validationError]. Test data are not inputs.
% totalIterations=[] preserves per-stage iterations. A total budget uses real generations.
if nargin<4, options=aco_mi_options(); end
defaults=aco_mi_options(); names=fieldnames(options);
for j=1:numel(names), defaults.(names{j})=options.(names{j}); end
options=defaults;
assert(options.construction=="fixed_size_roulette" && options.heuristicReference=="last_selected", ...
    'acomi:Profile','Only the documented construction profile is implemented.');
assert(ismember(options.fitnessMode,["author_eq11","common_objective"]));
assert(options.ants>=1 && options.iterations>=1 && options.numIntervals>=1);
if ~isempty(options.totalIterations)
    assert(isscalar(options.totalIterations) && isfinite(options.totalIterations) && ...
        options.totalIterations>=2 && options.totalIterations==floor(options.totalIterations), ...
        'acomi:TotalIterations','Two-stage ACO-MI requires at least two total iterations.');
    assert(options.numIntervals==floor(options.numIntervals), ...
        'acomi:IntervalCount','The number of feature-count intervals must be an integer.');
end
rng(options.seed,'twister'); totalClock=tic;
if isfield(options,'preparationModel')
    model=options.preparationModel;
    assert(model.m==size(Xtrain,2),'acomi:PreparationDimension','Cached training preparation has a different feature dimension.');
    if isfield(model,'lazyPairCache')
        model.lazyPairCache=containers.Map('KeyType','char','ValueType','double');
    end
    options=rmfield(options,'preparationModel');
    sharedPreparation=true;
else
    model=aco_mi_prepare(Xtrain,ytrain,options);
    sharedPreparation=false;
end
D=size(Xtrain,2); p=model.p;
if p>0 && ~isfield(model,'etaMatrix') && ~isempty(model.pairMatrix)
    FF=aco_mi_eidar(model.pairMatrix(model.patternID,model.patternID),model.globalMin,model.globalMax,model.m);
    model.etaMatrix=(model.CFMI(:)-FF+model.m)/(2*model.m-1);
end
sampler=[];samplerNote="MATLAB exact vectorized roulette";
if p>0 && isfield(model,'etaMatrix') && options.samplerBackend=="auto_net"
    [sampler,samplerNote]=aco_roulette_sampler("create",model.etaMatrix);
end
FEs=0; memory=struct([]); trace=struct([]); traceCount=0;
if p==0
    mask=false(1,D); [cost,errorRate]=objective(mask); FEs=1;
    result=struct('selectedMask',mask,'FEs',FEs,'commonCost',cost, ...
        'validationAccuracy',1-errorRate,'status',"no_positive_MI_features", ...
        'profile',"independent_reproduction_declared_assumptions_v1", ...
        'options',options,'preparation',preparationSummary(model),'totalSeconds',toc(totalClock));
    return;
end
[~,seed]=max(model.CFMI);
if isempty(options.totalIterations)
    n=min(options.numIntervals,p);
    intervalGenerations=repmat(options.iterations,n,1);
    secondStageGenerations=options.iterations;
    scheduleMode="per_stage";
else
    secondStageGenerations=min(20,max(1,round(options.totalIterations/5)));
    firstStageGenerations=options.totalIterations-secondStageGenerations;
    n=min([options.numIntervals,p,firstStageGenerations]);
    intervalGenerations=repmat(floor(firstStageGenerations/n),n,1);
    extraGenerations=mod(firstStageGenerations,n);
    intervalGenerations(1:extraGenerations)=intervalGenerations(1:extraGenerations)+1;
    scheduleMode="total_iterations";
end
schedule=struct('Mode',scheduleMode,'TotalIterations',sum(intervalGenerations)+secondStageGenerations, ...
    'FirstStageIntervals',n,'FirstStageGenerations',sum(intervalGenerations), ...
    'PerIntervalGenerations',intervalGenerations(:)', ...
    'SecondStageGenerations',secondStageGenerations);
intervals=[floor((0:n-1)'*p/n)+1 floor((1:n)'*p/n)];
intervalBestAccuracy=-Inf(n,1); intervalBestSize=Inf(n,1);
rho=ones(1,p)*options.initialPheromone;
for intervalID=1:n
    for generation=1:intervalGenerations(intervalID)
        [ants,rho]=generationStep(rho,intervals(intervalID,:),1,intervalID,generation);
        acc=[ants.accuracy]; count=[ants.count];
        bestAcc=max(acc); bestSize=min(count(abs(acc-bestAcc)<1e-12));
        if bestAcc>intervalBestAccuracy(intervalID)+1e-12 || ...
                (abs(bestAcc-intervalBestAccuracy(intervalID))<1e-12 && bestSize<intervalBestSize(intervalID))
            intervalBestAccuracy(intervalID)=bestAcc; intervalBestSize(intervalID)=bestSize;
        end
    end
end
bestAcc=max(intervalBestAccuracy);
ties=find(abs(intervalBestAccuracy-bestAcc)<1e-12);
% Section 3.2: tied maximum => interval with fewer features (lowest index).
chosenInterval=ties(1);
rho=ones(1,p)*options.initialPheromone;
if ~options.carryMemoryToStage2, memory=struct([]); end
for generation=1:secondStageGenerations
    [~,rho]=generationStep(rho,intervals(chosenInterval,:),2,chosenInterval,generation);
end
best=memory(1); selected=false(1,D); selected(model.retained(best.localFeatures))=true;
result=struct('selectedMask',selected,'selectedFeatures',find(selected),'FEs',FEs, ...
    'commonCost',best.commonCost,'validationAccuracy',best.accuracy,'paperFitness',best.paperFitness, ...
    'selectionScore',best.score,'selectedInterval',intervals(chosenInterval,:), ...
    'chosenIntervalID',chosenInterval,'intervals',intervals, ...
    'intervalBestAccuracy',intervalBestAccuracy,'intervalBestSize',intervalBestSize, ...
    'memory',memory,'trace',struct2table(trace),'finalPheromone',rho, ...
    'profile',"independent_reproduction_declared_assumptions_v1",'status',"ok", ...
    'options',options,'preparation',preparationSummary(model),'totalSeconds',toc(totalClock));
result.usedSharedPreparation=sharedPreparation;
result.samplerBackendUsed=samplerNote;
result.schedule=schedule;
if model.pilotCapped, result.status="pilot_feature_cap_not_formal_comparison"; end

    function [ants,nextRho]=generationStep(currentRho,sizeInterval,stage,intervalID,generation)
        ants=struct([]);
        if ~isempty(sampler),aco_roulette_sampler("set",sampler,currentRho,options.alpha,options.beta);end
        for antID=1:options.ants
            target=randi(sizeInterval); selectedLocal=zeros(1,target);selectedLocal(1)=seed;
            if ~isempty(sampler)
                selectedLocal=aco_roulette_sampler("select",sampler,seed,target,rand(1,target-1));
            else
            available=true(1,p);available(seed)=false;
            for selection=2:target
                candidates=find(available);
                eta=aco_mi_eta(model,candidates,selectedLocal(selection-1));
                weight=currentRho(candidates).^options.alpha.*eta.^options.beta;
                probability=weight/sum(weight);
                chosen=find(rand<=cumsum(probability),1,'first');
                if isempty(chosen), chosen=numel(candidates); end
                selectedLocal(selection)=candidates(chosen);available(candidates(chosen))=false;
            end
            end
            mask=false(1,D); mask(model.retained(selectedLocal))=true;
            [commonCost,errorRate]=objective(mask); FEs=FEs+1;
            accuracy=1-errorRate; count=sum(mask);
            assert(isfinite(accuracy) && accuracy>=0 && accuracy<=1);
            paperFitness=options.accuracyWeight*accuracy+options.sizeWeight*(model.m-count)/model.m;
            if options.fitnessMode=="author_eq11", score=paperFitness;
            else, score=-commonCost; end
            ant=struct('localFeatures',sort(selectedLocal),'count',count,'accuracy',accuracy, ...
                'commonCost',commonCost,'paperFitness',paperFitness,'score',score);
            if antID==1, ants=ant; else, ants(antID)=ant; end %#ok<AGROW>
        end
        memory=updateMemory(memory,ants,options.memorySize);
        deposit=zeros(1,p);
        for j=1:numel(ants)
            amount=options.phi*ants(j).accuracy+(1-options.phi)*(model.m-ants(j).count)/model.m;
            deposit(ants(j).localFeatures)=deposit(ants(j).localFeatures)+amount;
        end
        maxAcc=max([ants.accuracy]); bestIndices=find(abs([ants.accuracy]-maxAcc)<1e-12);
        [~,smallest]=min([ants(bestIndices).count]); bestAnt=ants(bestIndices(smallest));
        amount=options.phi*bestAnt.accuracy+(1-options.phi)*(model.m-bestAnt.count)/model.m;
        deposit(bestAnt.localFeatures)=deposit(bestAnt.localFeatures)+amount;
        nextRho=(1-options.evaporation)*currentRho+deposit;
        nextRho=max(realmin,nextRho);
        if options.pheromoneNormalization=="sum", nextRho=nextRho/sum(nextRho);
        else, error('acomi:Pheromone','Only explicit sum normalization is implemented.'); end
        traceCount=traceCount+1;
        row=struct('GlobalIteration',traceCount,'Stage',stage,'IntervalID',intervalID, ...
            'Generation',generation,'GenerationInterval',generation,'FEs',FEs, ...
            'MemoryBestScore',memory(1).score,'MemoryBestAccuracy',memory(1).accuracy, ...
            'MemoryBestCount',memory(1).count);
        if traceCount==1, trace=row; else, trace(traceCount)=row; end
        if options.verbose
            fprintf('ACO-MI independent | stage %d interval %d generation %d | FE %d\n',stage,intervalID,generation,FEs);
        end
    end
end

function memory=updateMemory(memory,ants,K)
if isempty(memory), combined=ants; else, combined=[memory ants]; end
keys=arrayfun(@(a)sprintf('%d_',a.localFeatures),combined,'UniformOutput',false);
[~,first]=unique(keys,'stable'); combined=combined(first);
score=[combined.score]'; acc=[combined.accuracy]'; count=[combined.count]';
[~,order]=sortrows([-score -acc count],[1 2 3]);
memory=combined(order(1:min(K,numel(order))));
end

function summary=preparationSummary(model)
summary=rmfield(model,intersect(fieldnames(model), ...
    {'patterns','patternID','multiplicity','pairMatrix','lazyPairCache','etaMatrix'}));
end
