function [output,note]=aco_roulette_sampler(action,varargin)
% Optional Windows .NET exact sampler; creation failure returns [] for fallback.
% [s,note]=aco_roulette_sampler("create",etaMatrix);
% aco_roulette_sampler("set",s,rho,alpha,beta);
% chosen=aco_roulette_sampler("select",s,seed,target,uniforms);
% ref=aco_roulette_sampler("reference",eta,rho,alpha,beta,seed,target,uniforms);
output=[]; note="";
switch string(action)
    case "create"
        eta=varargin{1};
        assert(ismatrix(eta) && size(eta,1)==size(eta,2) && ~isempty(eta));
        if ~ispc, note="non_Windows_pure_MATLAB_fallback"; return; end
        library=fullfile(fileparts(mfilename('fullpath')),'aco_roulette_sampler.dll');
        if ~isfile(library), note="missing_DLL_pure_MATLAB_fallback"; return; end
        try
            NET.addAssembly(library);
            fileLibrary=fullfile(fileparts(mfilename('fullpath')),'aco_roulette_sampler_file.dll');
            if isfile(fileLibrary)
                NET.addAssembly(fileLibrary);
                temporary=writeBinaryEta(eta);
                cleanup=onCleanup(@()deleteExactTemporary(temporary)); %#ok<NASGU>
                output=AcoExactRoulette.FileFactory.FromBinaryFile(temporary,int32(size(eta,1)));
                deleteExactTemporary(temporary);
                note="dotnet_exact_double_sequential_roulette_binary_input";
            else
                output=AcoExactRoulette.Sampler(double(eta(:)),int32(size(eta,1)));
                note="dotnet_exact_double_sequential_roulette_interop_input";
            end
        catch err
            output=[]; note="dotnet_unavailable_pure_MATLAB_fallback: "+string(err.message);
        end
    case "set"
        sampler=varargin{1};rho=varargin{2};
        sampler.SetPheromone(double(rho(:)),double(varargin{3}),double(varargin{4}));
    case "select"
        sampler=varargin{1};
        values=sampler.Select(int32(varargin{2}),int32(varargin{3}),double(varargin{4}(:)));
        output=reshape(double(values),1,[]);
    case "reference"
        eta=varargin{1};rho=varargin{2};alpha=varargin{3};beta=varargin{4};
        seed=varargin{5};target=varargin{6};uniforms=varargin{7};
        p=size(eta,1); output=zeros(1,target);output(1)=seed;
        available=true(1,p);available(seed)=false;
        for j=2:target
            candidates=find(available);
            weight=rho(candidates).^alpha.*reshape(eta(candidates,output(j-1)),1,[]).^beta;
            probability=weight/sum(weight);
            chosen=find(uniforms(j-1)<=cumsum(probability),1,'first');
            if isempty(chosen), chosen=numel(candidates); end
            output(j)=candidates(chosen);available(candidates(chosen))=false;
        end
    otherwise
        error('acomi:SamplerAction','Unknown sampler action.');
end
end

function filename=writeBinaryEta(eta)
% PID/counter naming never consumes the optimizer RNG stream.
persistent counter
if isempty(counter),counter=0;end
project=fileparts(fileparts(fileparts(fileparts(mfilename('fullpath')))));
folder=fullfile(project,'结果','temporary_samplers');
if ~exist(folder,'dir'),mkdir(folder);end
while true
    counter=counter+1;filename=fullfile(folder,sprintf('eta_%d_%d.bin',feature('getpid'),counter));
    if ~exist(filename,'file'),break;end
end
[fid,msg]=fopen(filename,'w','ieee-le');assert(fid>=0,'acomi:EtaBinaryWrite','%s',msg);
closeFile=onCleanup(@()fclose(fid)); %#ok<NASGU>
written=fwrite(fid,eta,'double',0,'ieee-le');
assert(written==numel(eta),'acomi:EtaBinaryWrite','Incomplete eta binary write.');
end

function deleteExactTemporary(filename)
% The exact new filename is the only deletion target, with no recursion.
if isfile(filename),delete(filename);end
end
