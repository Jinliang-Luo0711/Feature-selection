function MI=aco_mi_pair_cache(patterns)
% Exact empirical MI in pattern blocks via sparse contingency cross-products.
% Counts are integer-exact; no bin approximation or candidate cap is used.
n=size(patterns,1);U=size(patterns,2);K=double(max(patterns,[],1));
offset=[0 cumsum(K(1:end-1))];S=sum(K);stateFeature=repelem((1:U)',K);
stateFeature=stateFeature(:);
rr=repmat((1:n)',U,1);
repeatedOffset=repelem(offset(:),n);
cc=double(patterns(:))+repeatedOffset(:);
H=sparse(rr,cc,ones(numel(rr),1),n,S); count=full(sum(H,1));MI=zeros(U,U);
blockSize=32;
for first=1:blockSize:U
 last=min(U,first+blockSize-1); columns=(offset(first)+1):(offset(last)+K(last));
 block=H(:,columns)'*H;
 [r,c,v]=find(block);
 p=v/n;denom=count(columns(r)).*count(c);
 term=p.*log2((v*n)./reshape(denom,[],1));
 localFeature=stateFeature(columns(r))-first+1;
 sums=accumarray([localFeature stateFeature(c)],term,[last-first+1 U]);
 MI(first:last,:)=sums;
end
MI=max(0,(MI+MI')/2);
end
