function [Best_score,Acc,Nf,Sf,curve,dt,info] = ACO_MI(feat,label,N,T,HO,options)
% ACO-MI adapter for the original feature-selection experiment interface.
% N controls ant count. T controls total native two-stage generations.
% T=100 allocates 80 first-stage generations and 20 second-stage generations.
% curve contains real global-iteration records, including stage-2 reset.
% The optional seventh output records the seed, actual FEs and native trace.
if nargin < 6
    options = struct;
end
adapterClock = tic;
algorithmFolder = fullfile(fileparts(mfilename('fullpath')),'external','ACO_MI');
addpath(algorithmFolder);

assert(isnumeric(feat) && ismatrix(feat) && size(feat,1) == numel(label), ...
    'acomi:InputDimension','Feature rows and labels must have matching lengths.');
assert(isscalar(N) && isfinite(N) && N >= 1 && N == floor(N), ...
    'acomi:AntCount','The ant count must be a positive integer.');
assert(isscalar(T) && isfinite(T) && T >= 2 && T == floor(T), ...
    'acomi:IterationInput','Two-stage ACO-MI requires at least two total iterations.');
assert(isstruct(options) && isscalar(options), ...
    'acomi:Options','The optional configuration must be a scalar structure.');

label = label(:);
D = size(feat,2);
trainRows = HO.training == 1;
validationRows = HO.test == 1;
assert(numel(trainRows) == size(feat,1) && numel(validationRows) == size(feat,1), ...
    'acomi:PartitionDimension','The shared partition must match the input rows.');
assert(any(trainRows) && any(validationRows) && ~any(trainRows & validationRows), ...
    'acomi:Partition','Training and validation rows must form disjoint nonempty sets.');

config = aco_mi_options();
config.numIntervals = 10;
config.iterations = 20;
config.maxExactPairs = Inf;
config.maxCachedPatterns = Inf;
config.pilotFeatureCap = Inf;
config.verbose = false;
config.samplerBackend = "matlab";
names = fieldnames(options);
for j = 1:numel(names)
    assert(isfield(config,names{j}) || strcmp(names{j},'preparationModel'), ...
        'acomi:UnknownOption','Unknown ACO-MI option %s.',names{j});
    config.(names{j}) = options.(names{j});
end
config.ants = N;
config.fitnessMode = "common_objective";
config.totalIterations = T;

if ~isfield(options,'seed')
    config.seed = randi([0 2^32-1]);
end
assert(isscalar(config.seed) && isfinite(config.seed) && ...
    config.seed >= 0 && config.seed <= 2^32-1 && config.seed == floor(config.seed), ...
    'acomi:Seed','The search seed must be an integer in [0,2^32-1].');
callerRng = rng;
restoreCallerRng = onCleanup(@()rng(callerRng)); %#ok<NASGU>

if isfield(config,'preparationModel')
    prepared = config.preparationModel;
    assert(isfield(prepared,'mdl') && prepared.m == D && ...
        prepared.mdl.trainingRows == nnz(trainRows) && prepared.mdl.featureCount == D, ...
        'acomi:PreparationDimension','Shared preparation must match training rows and feature count.');
end

objectiveCalls = 0;
emptySubsetCalls = 0;
solution = aco_mi_reproduce(@evaluateSubset,feat(trainRows,:),label(trainRows),config);
assert(solution.FEs == objectiveCalls, ...
    'acomi:EvaluationCount','The adapter and optimizer evaluation counts differ.');

selected = logical(solution.selectedMask(:)');
Best_score = solution.commonCost;
Acc = solution.validationAccuracy;
Sf = find(selected);
Nf = nnz(selected);
if isfield(solution,'trace')
    nativeTrace = solution.trace;
    curve = reshape(-nativeTrace.MemoryBestScore,1,[]);
    curveDescription = "Real total-budget generations with stage-2 memory reset";
else
    nativeTrace = table(0,0,0,0,0,solution.FEs,-Best_score,Acc,Nf, ...
        'VariableNames',{'GlobalIteration','Stage','IntervalID','Generation','GenerationInterval','FEs', ...
        'MemoryBestScore','MemoryBestAccuracy','MemoryBestCount'});
    curve = repmat(Best_score,1,T);
    curveDescription = "Known penalty continued after no-positive-MI early stop";
end
assert(numel(selected) == D && numel(curve) == T && isfinite(Best_score) && ...
    isfinite(Acc) && Acc >= 0 && Acc <= 1 && abs(curve(end)-Best_score) < 1e-12, ...
    'acomi:Output','ACO-MI outputs are inconsistent.');

info = struct;
info.ActualFEs = objectiveCalls;
info.EmptySubsetCalls = emptySubsetCalls;
info.ClassifierFits = objectiveCalls-emptySubsetCalls;
info.SearchSeed = config.seed;
info.NativeSteps = size(nativeTrace,1);
info.DisplaySteps = numel(curve);
info.EarlyStop = solution.status == "no_positive_MI_features";
info.CurvePadding = info.DisplaySteps > info.NativeSteps;
info.PaddedSteps = info.DisplaySteps-info.NativeSteps;
info.Trace = nativeTrace;
info.Status = solution.status;
info.Options = solution.options;
info.SharedIterationInput = T;
info.CurveUnit = "global_iteration";
info.CurveDescription = curveDescription;
if isfield(solution,'schedule')
    info.Schedule = solution.schedule;
else
    info.Schedule = struct('Mode',"early_stop",'TotalIterations',0, ...
        'FirstStageIntervals',0,'FirstStageGenerations',0, ...
        'PerIntervalGenerations',zeros(1,0),'SecondStageGenerations',0);
end
info.UsedSharedPreparation = isfield(config,'preparationModel');
info.PreparationSeconds = solution.preparation.preparationSeconds;
info.OriginalFeatureCount = D;
info.RetainedFeatureCount = solution.preparation.p;
info.TrainingInstances = nnz(trainRows);
info.ValidationInstances = nnz(validationRows);
info.Implementation = "Independent ACO-MI reproduction, common-objective protocol adaptation";
dt = toc(adapterClock);
info.ElapsedSeconds = dt;

    function [fitness,errorRate] = evaluateSubset(mask)
        objectiveCalls = objectiveCalls+1;
        mask = logical(mask(:)');
        if any(mask)
            [fitness,errorRate] = jFitnessFunction(feat,label,mask,HO);
        else
            emptySubsetCalls = emptySubsetCalls+1;
            fitness = jFitnessFunction(feat,label,mask,HO);
            errorRate = 1;
        end
    end
end
