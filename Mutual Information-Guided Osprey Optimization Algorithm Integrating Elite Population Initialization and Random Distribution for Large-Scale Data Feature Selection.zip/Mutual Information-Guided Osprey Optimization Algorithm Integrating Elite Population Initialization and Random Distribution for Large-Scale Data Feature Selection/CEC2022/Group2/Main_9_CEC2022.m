clear,clc,close
cecDirectory = fileparts(mfilename('fullpath'));
cd(cecDirectory);
addpath(cecDirectory, '-begin');
% The supplied MEX binary supports Windows x64. Other platforms compile the source.
if exist(fullfile(cecDirectory, ['cec22_test_func.' mexext]), 'file') ~= 3
    mex('-O', fullfile(cecDirectory, 'cec22_test_func.cpp'), '-outdir', cecDirectory);
end
N=30;
LB=-100;
UB=100;
Dim=10;%维度可选10.20维，维度越高，难度越高
Max_Iter=500;
numRuns=30;
functionIndices=12; % Use 1:12 to run the full suite.
   for t = functionIndices
        F_obj=str2func('cec22_test_func');
        func_num = t;
        for i=1:numRuns
            [Best_F1,Best_P1,Curve1]=IIOOA_t(N,Max_Iter,LB,UB,Dim,F_obj,func_num);
            [Best_F2,Best_P2,Curve2]=AOA_CEC(N,Max_Iter,LB,UB,Dim,F_obj,func_num);
            [Best_F3,Best_P3,Curve3]=BAT(N,Max_Iter,LB,UB,Dim,F_obj,func_num);
            [Best_F4,Best_P4,Curve4]=COA(N,Max_Iter,LB,UB,Dim,F_obj,func_num);
            [Best_F5,Best_P5,Curve5]=CFOA(N,Max_Iter,LB,UB,Dim,F_obj,func_num);
            [Best_F6,Best_P6,Curve6]=FLO(N,Max_Iter,LB,UB,Dim,F_obj,func_num);
            [Best_F7,Best_P7,Curve7]=GCRA_CEC2022(N,Max_Iter,LB,UB,Dim,F_obj,func_num);
            [Best_F8,Best_P8,Curve8]=PDO_CEC(N,Max_Iter,LB,UB,Dim,F_obj,func_num);
            [Best_F9,Best_P9,Curve9]=RSA(N,Max_Iter,LB,UB,Dim,F_obj,func_num); 
            
            Cdata_BestF{t}(i,:)=[Best_F1,Best_F2,Best_F3,Best_F4,Best_F5,Best_F6,Best_F7,Best_F8,Best_F9];
            best_F1(i) = Best_F1;
            best_F2(i) = Best_F2;
            best_F3(i) = Best_F3;
            best_F4(i) = Best_F4;
            best_F5(i) = Best_F5;
            best_F6(i) = Best_F6;
            best_F7(i) = Best_F7;
            best_F8(i) = Best_F8;
            best_F9(i) = Best_F9;
            
            curve1(i,:)=Curve1;
            curve2(i,:)=Curve2;
            curve3(i,:)=Curve3;
            curve4(i,:)=Curve4;
            curve5(i,:)=Curve5;
            curve6(i,:)=Curve6;
            curve7(i,:)=Curve7;
            curve8(i,:)=Curve8;
            curve9(i,:)=Curve9;
            
        end
        mean_curve1 = mean(curve1,1);
        mean_curve2 = mean(curve2,1);
        mean_curve3 = mean(curve3,1);
        mean_curve4 = mean(curve4,1);
        mean_curve5 = mean(curve5,1);
        mean_curve6 = mean(curve6,1);
        mean_curve7 = mean(curve7,1);
        mean_curve8 = mean(curve8,1);
        mean_curve9 = mean(curve9,1);
        
        Cdata_curve{t}=[mean_curve1;mean_curve2;mean_curve3;mean_curve4;mean_curve5;mean_curve6;mean_curve7;mean_curve8;mean_curve9];
        Mean_best_F(t,:)=[mean(best_F1),mean(best_F2),mean(best_F3),mean(best_F4),mean(best_F5),mean(best_F6),mean(best_F7),mean(best_F8),mean(best_F9)];
        Std_best_F(t,:)=[std(best_F1),std(best_F2),std(best_F3),std(best_F4),std(best_F5),std(best_F6),std(best_F7),std(best_F8),std(best_F9)];
        Min_best_F(t,:)= [min(best_F1),min(best_F2),min(best_F3),min(best_F4),min(best_F5),min(best_F6),min(best_F7),min(best_F8),min(best_F9)]; 
        Max_best_F(t,:)= [max(best_F1),max(best_F2),max(best_F3),max(best_F4),max(best_F5),max(best_F6),max(best_F7),max(best_F8),max(best_F9)]; 
        
        figure(t); clf;

        semilogy(1:numel(mean_curve1), mean_curve1,'color',[0.89, 0.10, 0.11],'linewidth',1.2,'LineStyle', '--');hold on
        semilogy(1:numel(mean_curve2), mean_curve2,'color',[0.21, 0.63, 0.71],'Marker','>','markerindices',(1:25:numel(mean_curve2)),'MarkerSize',4.2,'linewidth',1.2,'LineStyle', '-.');hold on
        semilogy(1:numel(mean_curve3), mean_curve3,'color',[0.47, 0.67, 0.19],'Marker','p','markerindices',(1:25:numel(mean_curve3)),'MarkerSize',4.2,'linewidth',1.2);hold on
        semilogy(1:numel(mean_curve4), mean_curve4,'Color',[0.99, 0.55, 0.14],'Marker','<','markerindices',(1:25:numel(mean_curve4)),'MarkerSize',4.2,'linewidth',1.2,'LineStyle', '--');hold on
        semilogy(1:numel(mean_curve5), mean_curve5,'Color',[0.58, 0.39, 0.67],'Marker','o','markerindices',(1:25:numel(mean_curve5)),'MarkerSize',4.2,'linewidth',1.2,'LineStyle', '-.');hold on
        semilogy(1:numel(mean_curve6), mean_curve6,'Color',[0.95, 0.76, 0.00],'Marker','^','markerindices',(1:25:numel(mean_curve6)),'MarkerSize',4.2,'linewidth',1.2);hold on
        semilogy(1:numel(mean_curve7), mean_curve7,'Color',[0.60, 0.60, 0.60],'Marker','d','markerindices',(1:25:numel(mean_curve7)),'MarkerSize',4.5,'linewidth',1.2,'LineStyle', '--');hold on
        semilogy(1:numel(mean_curve8), mean_curve8,'Color',[0.30, 0.75, 0.93],'Marker','v','markerindices',(1:25:numel(mean_curve8)),'MarkerSize',4.2,'linewidth',1.2,'LineStyle', '-.');hold on
        semilogy(1:numel(mean_curve9), mean_curve9,'Color',[0.60, 0.31, 0.07],'Marker','s','markerindices',(1:25:numel(mean_curve9)),'MarkerSize',4.5,'linewidth',1.2);hold on
        
        title('Convergence curve')
%         xlabel('Iteration');
        xlabel('Number of iterations');
        ylabel('Best fitness function');
        axis tight
        legend('DLMt-OOA','AOA','BAT','COA','CFOA','FLO','GCRA','PDO','RSA')
   end



