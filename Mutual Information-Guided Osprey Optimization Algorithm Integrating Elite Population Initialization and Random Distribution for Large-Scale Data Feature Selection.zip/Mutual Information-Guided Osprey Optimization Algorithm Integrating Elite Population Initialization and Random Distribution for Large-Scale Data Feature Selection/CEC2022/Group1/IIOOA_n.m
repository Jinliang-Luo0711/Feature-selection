



%%% Designed and Developed by Pavel Trojovský and Mohammad Dehghani %%%


function[Best_score,Best_pos,OOA_curve]=IIOOA_n(SearchAgents,Max_iterations,lowerbound,upperbound,dimension,fitness,num)
lowerbound=ones(1,dimension).*(lowerbound);                              % Lower limit for variables
upperbound=ones(1,dimension).*(upperbound);                              % Upper limit for variables

%% INITIALIZATION
% for i=1:dimension
%     X(:,i) = lowerbound(i)+rand(SearchAgents,1).*(upperbound(i) - lowerbound(i));                          % Initial population
% end

%% 方法1：常规随机初始化（共享基础种群）
X_random = zeros(SearchAgents, dimension);
for i = 1:dimension
    X_random(:,i) = lowerbound(i) + rand(SearchAgents,1) .* (upperbound(i) - lowerbound(i));
end

%% 方法2：基本反向学习初始化（基于X_random）
X_opp_basic_rev = zeros(SearchAgents, dimension);
for i = 1:dimension
    X_opp_basic_rev(:,i) = lowerbound(i) + upperbound(i) - X_random(:,i);  % 直接基于X_random计算
end

%% 方法3：基于群体中心的引力反向学习初始化（基于X_random）
% 计算种群中心
population_center = mean(X_random);

% 计算引力反向种群
X_opp_grav = zeros(SearchAgents, dimension);
for i = 1:dimension
    % 初始化阶段使用固定引力因子
    gravity_factor = 0.5;
    
    for j = 1:SearchAgents
        % 计算个体到中心的距离
        distance_to_center = abs(X_random(j,i) - population_center(i));
        
        % 基于引力的反向点生成
        if X_random(j,i) <= population_center(i)
            X_opp_grav(j,i) = upperbound(i) + population_center(i) - X_random(j,i) ...
                           + gravity_factor * distance_to_center;
        else
            X_opp_grav(j,i) = lowerbound(i) + population_center(i) - X_random(j,i) ...
                           - gravity_factor * distance_to_center;
        end
        
        % 边界处理
        X_opp_grav(j,i) = min(max(X_opp_grav(j,i), lowerbound(i)), upperbound(i));
    end
end

%% 合并三种初始化方法的结果并选择最优个体
% 合并所有生成的种群（减少到3种：随机解+基本反向解+引力反向解）
combined_pop = [X_random; X_opp_basic_rev; X_opp_grav];  % 共3*SearchAgents个个体

% 计算适应度
total_agents = 3 * SearchAgents;
fitness_values = zeros(total_agents, 1);
for i = 1:total_agents
    fitness_values(i) = fitness(combined_pop(i,:)', num);
end

% 按适应度排序并选择最优的SearchAgents个个体
[~, sorted_idx] = sort(fitness_values);
X = combined_pop(sorted_idx(1:SearchAgents), :);  % 最终选择的基础种群

% 求平均位置
Mean_X = mean(X); 
% 结束

for i =1:SearchAgents
    L=X(i,:);
    fit(i)=fitness(L',num);
end
%%

for t=1:Max_iterations  % algorithm iteration
    
    %%  update: BEST proposed solution
    [Fbest , blocation]=min(fit);
    
    if t==1
        xbest=X(blocation,:);                                           % Optimal location
        fbest=Fbest;                                           % The optimization objective function
    elseif Fbest<fbest
        fbest=Fbest;
        xbest=X(blocation,:);
    end
    %%
    %%
    for i=1:SearchAgents
        %% Phase 1: : POSITION IDENTIFICATION AND HUNTING THE FISH (EXPLORATION)
        fish_position=find(fit<fit(i));% Eq(4)
        r1=rand();
        if size(fish_position,2)==0
            selected_fish=xbest;
        else
            % 原始算法
            % if r1<0.5
            %     selected_fish=xbest;
            % else
            %     k=randperm(size(fish_position,2),1);
            %     selected_fish=X(fish_position(k));
            % end
            % 原始算法

            if r1<0.5
                selected_fish=xbest;
            elseif r1<0.75
                selected_fish=Mean_X;
            else
                k=randperm(size(fish_position,2),1);
                selected_fish=X(fish_position(k));
            end
        end
        %加入正态分布
        RB=0.3*abs(randn(SearchAgents,dimension)); 
        %结束

        I=round(1+rand);

        % 原始算法计算公式
        % X_new_P1=X(i,:)+rand(1,1).*(selected_fish-I.*X(i,:));%Eq(5)
        % 结束

        X_new_P1=X(i,:)+RB(i,:).*(selected_fish-I.*X(i,:));%Eq(5)
        X_new_P1 = max(X_new_P1,lowerbound);X_new_P1 = min(X_new_P1,upperbound);
        
        % update position based on Eq (6)
        L=X_new_P1;
        fit_new_P1=fitness(L',num);
        if fit_new_P1<fit(i)
            X(i,:) = X_new_P1;
            fit(i) = fit_new_P1;
        end
        %% END Phase 1
        
        %%
        %% PHASE 2: CARRYING THE FISH TO THE SUITABLE POSITION (EXPLOITATION)
        X_new_P1=X(i,:)+(lowerbound+rand*(upperbound-lowerbound))/t;%Eq(7)
        X_new_P1 = max(X_new_P1,lowerbound);X_new_P1 = min(X_new_P1,upperbound);
        % update position based on Eq (8)
        L=X_new_P1;
        fit_new_P1=fitness(L',num);
        if fit_new_P1<fit(i)
            X(i,:) = X_new_P1;
            fit(i) = fit_new_P1;
        end
        %% END Phase 2
        %%
    end
    %%
    
    best_so_far(t)=fbest;
    average(t) = mean (fit);
    
end
Best_score=fbest;
Best_pos=xbest;
OOA_curve=best_so_far;
end

